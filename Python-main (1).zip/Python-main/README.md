# DrowseGuard Pro: AI-Powered Drowsiness Detection

DrowseGuard Pro is a robust, real-time safety monitoring system built with **Django**, **OpenCV**, and **MediaPipe**. It detects drowsiness and yawning using facial landmark analysis and provides immediate audio/SMS alerts.

## 🚀 Key Features

- **User Authentication**: Secure Login/Registration pages; only authorized drivers can access their dashboard.
- **MySQL Persistence**: All yawns and drowsy episodes are recorded in a structured MySQL database and linked to the specific authenticated user.
- **Real-time Monitoring**: High-accuracy Eye Aspect Ratio (EAR) and Mouth Aspect Ratio (MAR) tracking.
- **Alert System**: 
  - **Audio**: Immediate beep notifications via Pygame.
  - **SMS**: Twilio integration to alert emergency contacts after 15 seconds of continuous drowsiness.
- **Admin Dashboard**: View detection history and user logs via the built-in Django Admin.

## 🛠️ Installation & Setup

### 1. Prerequisites
- Python 3.10+
- MySQL Server

### 2. Clone & Install Dependencies
```powershell
pip install -r requirements.txt
```

### 3. Database Setup
1. Create a database named `drowsy_db` in MySQL.
2. Update the `DATABASES` credentials in `core/settings.py` if your local MySQL configuration differs.

### 4. Configuration
- **Twilio**: Update the following variables in `drowsiness/views.py` to enable SMS alerts:
  - `ACCOUNT_SID`, `AUTH_TOKEN`, `TWILIO_FROM`, `ANUSHRI_NUMBER`

### 5. Running the Application
```powershell
# 1. Apply Migrations
python manage.py migrate

# 2. Start the Server
python manage.py runserver
```

## 🖥️ Usage
1. Open your browser and navigate to `http://127.0.0.1:8000/`.
2. **First Time?** Click "Sign Up" to create your driver account.
3. **Login**: Use your credentials to access the DrowseGuard Dashboard.
4. **Monitoring**: Once the camera feed loads, it begins real-time detection immediately.
5. **View History**: Access `http://127.0.0.1:8000/admin` to review the detection logs (Requires creating a superuser via `python manage.py createsuperuser`).

## ⚙️ How it works
- **Drowsiness**: Detected when the EAR drops below 0.25 for more than 20 frames.
- **Yawning**: Detected when the MAR exceeds 0.80.
- **Data storage**: Every event is captured and stored with a timestamp and the respective User ID in the MySQL database.